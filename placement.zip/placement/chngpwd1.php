<html>
<head>
 
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  
  
</head>
<body>
<style>
    
 
 .change-password-form {
  width: 300px;
  box-shadow: 0 0 3px 0 rgba(0,0,0,0,3);
  background: #fff;
  padding: 20px;
  margin: 8% auto 0;
  text-align: center;
 }
 
 .input-box{
 border-radius: 20px;
 padding: 10px;
 margin: 10px 0;
 width: 100%;
 border: 1px solid #999;
 outline: none;
 }
 button{
 color: #fff;
 width: 100%;
 padding: 10px;
 border-radius: 20px;
 font-size: 15px;
 margin: 10px 0;
 border: none;
 outline: none;
 cursor: pointer;
 }
 .submit{
 background-color: #1c8adb;
 }

</style>
 
 
 </div>
 <div class="change-password-form"> 

<center>
<h2> Change Password</h2>
 <form action="changepassword1.php" method="post">
     </br></br>
  <label for="email"><b>Enter email</b></label>
    <input type="text" class="input-box" placeholder="Enter email" name="email1" required><br>
    <label for="old password"><b>Old Password</b></label>
    <input type="text" class="input-box" placeholder="Enter Old Password" name="password1" required><br>
    <label for="New Password"><b>New Password</b></label>
    <input type="newpassword" class="input-box" placeholder="Enter New Password" name="newpassword" required><br>
   
    <button type="submit"<input type="submit" class="btn btn-primary" name="submit">Submit</button><br><br><br></center>
  </form>
</center>
</div></body>
</html>



